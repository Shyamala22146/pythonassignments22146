#Write a program to display sum of odd numbers and even numbers
#that fall between 12 and 37(including both numbers)
"""even=list()
for i in range(12,37,2):
    even.append(i)
    print(even)"""
        
#3Write a program to display all the numbers which are
#divisible by 11 but not by 2 between 100 and 500
"""for i in range(100,501):
    if i%11==0 and i%2!=0:
        print(i,end=" ")"""

""" o/p
 121 143 165 187 209 231 253 275 297 319 341 363 385 407 429 451 473 495""" 
       
#4.Write a program to print numbers from 1 to 20 except multiple of 2 & 3
"""for i in range(1,21):
    if i%2!=0 and i%3!=0:
        print(i,end=" ")"""
"""o\p1 5 7 11 13 17 19"""
#12.Write a Python program that prints all the numbers from 0 to 6 except 3 and 6. 

#Note : Use 'continue' statement.
"""for i in range(6):
    if (i==3 and i==6):
        continue
    print(i,end=" ")"""
"""O\p
0 1 2 3 4 5"""

#11
for fizzbuzz in range(51):
    if fizzbuzz % 3 == 0 and fizzbuzz % 5 == 0:
        print("fizzbuzz")
        continue
    elif fizzbuzz % 3 == 0:
        print("fizz")
        continue
    elif fizzbuzz % 5 == 0:
        print("buzz")
        continue
    print(fizzbuzz)
