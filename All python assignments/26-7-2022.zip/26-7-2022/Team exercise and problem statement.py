#1.WAP to reverse a number
"""n=int(input("enter a number"))
revnum=0
while n!=0:
    digit=n%10
    revnum=revnum*10+digit
    n//=10
print(revnum)"""
'''o\p:
enter a number145'''


#2. WAP to count  the number  occurrence/frequency  of a  each character in a string .
"""freq = {}
  
for i in freq:
    if i in freq:
        freq[i] += 1
    else:
        freq[i] = 1
        print("frequency  of a  each character in a string:", freq)"""

#3. WAP  to check length of two string is equal or not.
"""a=input("enter string1:")
b=input("enter string2:")
s=len(a)
x=len(b)
if s==x:
    print("length of string1 = string2")
else:
    print("length of strings are not equal")"""

"""output:
enter string1:abcdeh
enter string2:vghijkl
length of strings are not equal"""



 #4. Python program to print even numbers up to 100
"""for i in range(0,101):
    if i%2==0:
        print(i,',', end='')"""
"""0 ,2 ,4 ,6 ,8 ,10 ,12 ,14 ,16 ,18 ,20 ,22 ,24 ,26 ,28 ,30 ,32 ,34 ,36 ,38 ,40 ,42 ,44 ,46 ,48 ,50 ,52 ,54 ,56 ,58 ,60 ,62 ,64 ,66 ,
68 ,70 ,72 ,74 ,76 ,78 ,80 ,82 ,84 ,86 ,88 ,90 ,92 ,94 ,96 ,98 ,100"""

#5. Write a program in python to find greatest among three integers 
"""Num1=int(input("Enter a Number Num1:"))
Num2=int(input("Enter a Number Num2:"))
Num3=int(input("Enter a Number Num3:"))
if Num1>Num2 and Num1>Num3:
    print("Num1 is greater:", Num1)
elif Num2>Num3:
    print("Num2 is Greater:", Num2)
elif Num3>Num2 and Num3>Num1:
    print("Num3 is Greater:", Num3)
else:
    print("Num1, Num2, Num3, are equal:", Num1)"""

"""Enter a Number Num1:45
Enter a Number Num2:25
Enter a Number Num3:65
Num3 is Greater: 65"""
 #problem statment
#####_______________________________________________________________________
"""Q. Given an integer,n, perform the following conditional actions:

=>If  is odd, print Weird
=>If  is even and in the inclusive range of  2 to 5 , print "Not Weird"
=>If  is even and in the inclusive range of 6 to 20, print "Weird"
=>If  is even and greater than 20, print "Not Weird"

Input Format:
------------

A single line containing a positive integer, n.

Constraints:
-----------
=> 1<=n<=100

Output Format:
-------------

Print "Weird" if the number is weird. Otherwise, print "Not Weird".

sample input 1:
------
    3

output 1:
------
    Weird

explanation 1:
------------
    n=3
    n is odd and odd numbers are weird, so print "Weird".

sample input 2:
------
    24

------------------------------or------------------------------------------
output 2:
------
    Not Weird

explanation 2:
------------
    n=24
    n>20  and nis even,so it is  print " Not Weird"."""
"""n= int(input("enter a number:"))
if n%2==1:
    print("Weird")
elif n%2==0 and n<5:
    print("Not weird")
elif n%2==0 and n>20:
    print("Not weird")
elif n%2==0:
    for n in range(6,20):
        print("weird")"""
  
"""o/p:enter a number:24
Not weird"""

