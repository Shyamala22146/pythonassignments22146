#1.  Add a list of elements to a given set
"""a=set()
l=[1,2,3,5,6]
for i in l:
    a.add(i)
print(a)
 a={'apple', 'banana','grapes'}"""
 
#2. Return a set of identical items from a given two Python
"""a={'apple', 'banana','grapes'}
b={'apple', 'banana','grapes','orange'}
x=a.intersection(b)
print(x)
{'apple', 'grapes', 'banana'}"""



#3.Returns a new set with all items from both sets by removing duplicates
"""a={'apple', 'banana','grapes'}
b={'apple', 'banana','grapes','orange'}
x=a.union(b)
print(x)
{'banana', 'orange', 'apple', 'grapes'}"""

#4.Given two Python sets, update first set with items that exist only in the first set
#and not in the second set.
"""a={'apple', 'banana','grapes','pappaya'}
b={'apple', 'banana','grapes','orange'}
a.difference_update(b)
print(a)
o\p:{'pappaya'}"""


#5.Remove 10, 20, 30 elements from a following set at once
"""a={10,20,30,40,50}
b={10,20,30}
a.difference_update(b)
print(a)
{40, 50}"""


#6.Return a set of all elements in either A or B, but not both
"""a={10,20,30,40,50}
b={10,20,70,80,90}

print(a.symmetric_difference(b))
{80, 50, 90, 70, 40, 30}"""

#7.Determines whether or not the following two sets have any elements in common.
#If yes display the common elements
"""a={10,20,30,40,50}
b={10,20,70,80,90}
print(a & b)
O|P:{10, 20}"""

#8. Update set1 by adding items from set2, except common items
"""a={10,20,30,40,50}
b={10,20,70,80,90}
a.symmetric_difference_update(b)
print(a)
{80, 50, 90, 70, 40, 30}"""
#9. Remove items from set1 that are not common to both set1 and set2
"""a={10,20,30,40,50}
b={10,20,70,80,90}
a.intersection_update(b)
print(a)"""

#10.Write a Python program to check if a given set is superset of itself
#and superset of another given set
"""x = {"f", "e", "d", "c", 1,2,3}
y = {"s", "d", "c"}

z = x.issuperset(y)
a=x.issuperset(x)
print(z,a)"""
#11.Write a Python program to check a given set has no elements in common
#with other given set
"""x = {"f", "e", "d", "c", "b", "a"}
y = {"a", "b", "c"}
z={1,2,3,4}
print(x.isdisjoint(y))
print(x.isdisjoint(z))
print(y.isdisjoint(z))
False
True
True"""      
    
#12.Write a Python program to remove the intersection of a 2nd set from the 1st set.
"""x = {"f", "e", "d", "c", 1,2,3}
y = {"s", "d", "c"}
print(x-y)
{1, 2, 3, 'e', 'f'}"""


#13. Perform all sets methods by taking an example of your own.


'''x={"f", "e", "d", "c", 1,2,3}
"""x.add(7)
print(x)
{'c', 1, 2, 3, 'd', 'f', 7, 'e'}"""
"""print(x.pop())
1"""
x.remove(2)
print(x)
{'e', 1, 3, 'c', 'f', 'd'}
b=x.copy
print(x)
{'e', 1, 3, 'c', 'f', 'd'}
#b={1,2,3}
"""y=b.issuperset(x)
s=x.issuperset(b)
print(y,s)
False True
d=b.issubset(x)
print(d)
True'''


"""x = {"apple", "banana", "cherry"}
y = {"google", "microsoft", "apple"}

z = x.intersection(y)
x.intersection_update(y)

print(x) 

print(z) 

o\p:{'apple'}
{'apple'}"""

'''x = {"apple", "banana", "cherry"}
y = {"google", "microsoft", "apple"}

z = x.difference(y)
x.difference_update(y)

print(x) 

print(z)
o\p:{'banana', 'cherry'}
{'banana', 'cherry'}'''

"""x = {"apple", "banana", "cherry"}
y = {"google", "microsoft", "apple"}

z = x.symmetric_difference(y)

x.symmetric_difference_update(y) 

print(z)
{'microsoft', 'cherry', 'google', 'banana'}"""


'''x = {"apple", "banana", "cherry"}
y = {"google", "microsoft", "facebook"}

z = x.isdisjoint(y)

print(z)
True'''

"""x = {"apple", "banana", "cherry"}
y = {"google", "microsoft", "apple"}

z = x.union(y)

print(z)

{'google', 'microsoft', 'banana', 'apple', 'cherry'}"""
