#1.WAP to find the senior citizens in the given list,list values should take dynamicaly (or) from the user only.
# suppose list=[23,67,45,89,65,12,15,19], and output:[65,67,89]
#final list should be in accending order.
# person age is 60 (or) more than 60 belongs to senior citizens.?

"""lst=list(map(int,input("enter the list of age:").split(',')))
l=[]
for i in lst:
    if i>=60:
        l.append(i)
        l.sort()
print("senior citizens:", l)"""
"""o/p:enter the list of age:45,66,89,54,78
senior citizens: [66, 78, 89]"""
  
#======================================================================================================================

#2. WAP to find the diagonal matrix absolute difference?
# suppose  1   2  3
#          7   9  3
#         12   5  67
#result:=>53
ls =[]
for i in range(3):
    ls1 =[]
    for j in range(3):
       ls1.append(int(input("enter a value:")))
    ls.append(ls1)    
print(ls)  
temp = 0
for i in range(len(ls)):
    temp = temp + ls[i][i]
emp = 0 
for j in range(len(ls)):
    emp = emp + ls[j][len(ls)-1-j]

print(abs(temp-emp))


#======================================================================================================================

#3. WAP to solve this pattern
"""  A
     A B
     A B C
     A B C D
     A B C D E
     A B C D
     A B C
     A B
     A  """
"""for i in range(65,71):
    for j in range(65,i):
          print(chr(j), end =' ')
    print()    
for i in range(69,65,-1):
    for j in range(65,i):
        print(chr(j), end = ' ')
    print() """ 
"""A 
A B 
A B C 
A B C D 
A B C D E 
A B C D 
A B C 
A B 
A"""

     
  
