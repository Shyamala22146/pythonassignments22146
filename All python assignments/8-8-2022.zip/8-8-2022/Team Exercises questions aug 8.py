#               3-Exercises
#               -----------
#======================================================================================================================

#1.WAP to find the senior citizens in the given list,list values should take dynamicaly (or) from the user only.
# suppose list=[23,67,45,89,65,12,15,19], and output:[65,67,89] final list should be in accending order.
# person age is 60 (or) more than 60 belongs to senior citizens.?

#======================================================================================================================

#2. WAP to find the diagonal matrix absolute difference?
# suppose  1   2  3
#          7   9  3
#         12   5  67
#result:=>53

#======================================================================================================================

#3. WAP to solve this pattern
"""  A
     A B
     A B C
     A B C D
     A B C D E
     A B C D
     A B C
     A B
     A         """"
