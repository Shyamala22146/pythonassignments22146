#1.Take 10 integer inputs from user and store them in a list and print them on
#screen.
"""a=[]
for i in range(1,11):
    a.append(int(input(f"enter {i} number:")))
print(a)"""
'O/p[1, 2, 3, 4, 5, 88, 99, 56, 47, 100]'

#2.Take 10 integer inputs from user and store them in a list.
#Again ask user to give a number. Now, tell user whether that number is present in list or not.
#( Iterate over list using while loop )
"""a=[]

for i in range(1,11):
    a.append(int(input(f"enter {i} number:")))
print(a)
n=int(input("enter a number"))
while n in a:
    print("True")
    break
else:   
    print("false")"""
"""o/p:enter 1 number:1
enter 2 number:2
enter 3 number:3
enter 4 number:45
enter 5 number:56
enter 6 number:88
enter 7 number:98
enter 8 number:25
enter 9 number:66
enter 10 number:14
[1, 2, 3, 45, 56, 88, 98, 25, 66, 14]
enter a number14
True"""
#3..
"""Take 20 integer inputs from user and print the following:
number of positive numbers
number of negative numbers
number of odd numbers
number of even numbers
number of 0s"""
"""a=[]
p,n,o,e,z=0,0,0,0,0
for i in range(1,21):
    a.append(int(input(f"enter {i} number:")))

for n in a:
    if(n>0):
        p+=1
    if(n<0):
        n+=1
    if(n%2!=0):
        o+=1
    if(n%2==0):
        e+=1
    if(n==0):
        z+=1

print("no. of Positive numbers:",p)
print("no. of Negative numbers:",n)
print("no. of odd numbers:",o)
print("no. of even numbers:",e)
print("no. of zeros",z)"""
"""enter 1 number:25
enter 2 number:2
enter 3 number:0
enter 4 number:-9
enter 5 number:-6
enter 6 number:4
enter 7 number:87
enter 8 number:56
enter 9 number:90
enter 10 number:78
enter 11 number:23
enter 12 number:-5
enter 13 number:33
enter 14 number:47
enter 15 number:1
enter 16 number:2
enter 17 number:9
enter 18 number:8
enter 19 number:7
enter 20 number:6
no. of Positive numbers: 16
no. of Negative numbers: 6
no. of odd numbers: 9
no. of even numbers: 11
no. of zeros 1"""

#5.Write a program to find the sum of all elements of a list.
"""a=[0,1,2,3,4,5]
s=0
for i in a:
    s=s+i
print("Sum of list a is :", s)"""
'o/pSum of list a is : 15'
#6.Write a program to find the product of all elements of a list
'''a=[1,2,3,4,5]
p=1
for i in a:
    p=p*i
print("product of list a is :", p)'''
'o/p:product of list a is : 120'
#7.Initialize and print each element in new line of a list inside list.
"""my_list = [1, 2, 3, 4]
print(*my_list, sep="\n")"""
#8Find largest and smallest elements of a list.
"""a=[1,4,5,8,9]
print(min(a), max(a))
1 9"""
#9.Write a program to print sum, average of all numbers, smallest and largest element of a list.
"""a=[0,1,2,3,4,65]
s=0
n=len(a)
for i in a:
    s=s+i
    avg=s//n
print("Sum of list is", s,"average of all numbers", avg)
print(min(a), max(a))"""
#10Write a program to check if elements of a list are same or not it read from front or back.
#E.g.-
#2	3	15	15	3	2
"""l=[2,3,15,15,3,2]
ele=l[0]
chk=True
for i in l:
    if ele!=i:
        chk=False
        break
    if(chk==True):
        print("equal")
    else:
        print("not equal")"""
#11.Take a list of 10 elements. Split it into middle and store
    #the elements in two dfferent lists
"""a=[58, 24, 13, 15, 63, 9, 8, 81, 1, 78]

newlist1=a[:5]
newlist2=a[5:]
print(newlist1,newlist2)"""
'o\p[58, 24, 13, 15, 63] [9, 8, 81, 1, 78]'  
