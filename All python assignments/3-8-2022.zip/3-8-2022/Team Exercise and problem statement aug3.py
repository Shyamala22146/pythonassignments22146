#1.what is a variable in and describe the role of variable in python memory management?
"""Variables are used to store data, they take memory space based on the
type of value we assigning to them.they are managed by heap
AND IF A VARIABLE IS not in use it deletesfrom memory"""
#________________________________________________________________

#2.what are the advantages and disadvantages of type casting?
"""#Type Casting is the method to convert the variable data type
into a certain data type in order to the operation required to be performed by users."""



#___________________________________________________________________
#3.what is the difference between while loop and for loop?
"""The for statement iterates through a collection or iterable object
The while statement simply loops until a condition is False"""

#_____________________________________________________________________
#4.write 5 string method with example?
"""capitalize:Upper case the first letter in this sentence
a="hello world"
print(a.capitalize())
casefold():Make the string lower case"""
"""a="HELLO"
print(a.casefold())
hello"""
"""count():returns number of times the value is present in the string"""
"""a='hello how are you?'
print(a.count('e'))
2"""
"""isalpha():Check if all the characters in the text are letters:"""
"""a="helloworld123"
print(a.isalpha())
False"""
'''join()Join all items in a tuple into a string,
using a hash character as separator:'''
"""myTuple = ("John", "Peter", "Vicky")

x = "#".join(myTuple)

print(x)
John#Peter#Vicky"""

#_______________________________________________________________________________________________

#5.write the Precedence rule of python with example?
"""precedence affects how an expression is evaluated.
For example, x = 7 + 3 * 2; here, x is assigned 13, not 20
because operator * has higher precedence than +,
so it first multiplies 3*2 and then adds into 7"""

####problemsolving#####
"""Write a program to check whether the given password is valid or not .
conisder the password to be valid if it contain at least one digit ands one capital.
input:it will be a single line containng string
output: valid password or invalid password
ex:GJ22191gopi
ouput:valid password"""
"""s=input("enter a password:")
l, u,d = 0, 0, 0
if (len(s) >= 8):
    for i in s:
        if (i.islower()):
            l+=1
        if (i.isupper()):
            u+=1           
        if (i.isdigit()):
            d+=1           
if (l>=1 and u>=1 and d>=1 and l+u+d==len(s)):
    print("Valid Password")
else:
    print("Invalid Password")"""
"""output enter a password:GJ22191gopi
Valid Password"""
    


