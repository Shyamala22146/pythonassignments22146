#Python exercises 

#1.Write a program which will find all such numbers which are divisible by 7 but are not a
#multiple of 5,between 2000 and 3200 (both included). 
#The numbers obtained should be printed in a comma-separated sequence on a single line.

"""for i in range(2000, 3200):
    if i %7==0 and i%5!=0:
        print(i, end=' ,')"""

"""output
2002 ,2009 ,2016 ,2023 ,2037 ,2044 ,2051 ,2058 ,2072 ,2079 ,2086 ,2093 ,2107 ,2114 ,
 2121 ,2128 ,2142 ,2149 ,2156 ,2163 ,2177 ,2184 ,2191 ,2198 ,2212 ,2219 ,2226 ,2233 ,
 2247 ,2254 ,2261 ,2268 ,2282 ,2289 ,2296 ,2303 ,2317 ,2324 ,2331 ,2338 ,2352 ,2359 ,
 2366 ,2373 ,2387 ,2394 ,2401 ,2408 ,2422 ,2429 ,2436 ,2443 ,2457 ,2464 ,2471 ,2478 ,
 2492 ,2499 ,2506 ,2513 ,2527 ,2534 ,2541 ,2548 ,2562 ,2569 ,2576 ,2583 ,2597 ,2604 ,
 2611 ,2618 ,2632 ,2639 ,2646 ,2653 ,2667 ,2674 ,2681 ,2688 ,2702 ,2709 ,2716 ,2723 ,
 2737 ,2744 ,2751 ,2758 ,2772 ,2779 ,2786 ,2793 ,2807 ,2814 ,2821 ,2828 ,2842 ,2849 ,
 2856 ,2863 ,2877 ,2884 ,2891 ,2898 ,2912 ,2919 ,2926 ,2933 ,2947 ,2954 ,2961 ,2968 ,
 2982 ,2989 ,2996 ,3003 ,3017 ,3024 ,3031 ,3038 ,3052 ,3059 ,3066 ,3073 ,
 3087 ,3094 ,3101 ,3108 ,3122 ,3129 ,3136 ,3143 ,3157 ,3164 ,3171 ,3178 ,3192 ,3199 ,"""



#___________________________________________________________________________________________________________

"""#2.Write a program which can compute the factorial of a given numbers. 
The results should be printed in a comma-separated sequence on a single line. 
Suppose the following input is supplied to the program: 
8 
Then, the output should be: 
40320"""

"""a=int(input("enter a value"))
fact=1
for i in range(1,a+1):
    fact=fact*i
print(fact)"""


'''o/p
enter a value8
40320'''

#------------------------------------------------------------------------------------------------

"""#3.With a given integral number n, write a program to generate a dictionary that contains
(i, i*i) such that is an integral number between 1 and n (both included). and
then the program should print the dictionary. 
Suppose the following input is supplied to the program: 
8 
Then, the output should be: 
{1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64}"""

"""n=int(input("enter a value"))
mydict= {x:x**2 for x in range (1,9)}
print(mydict)"""


"""enter a value8
{1: 1, 2: 4, 3: 9, 4: 16, 5: 25, 6: 36, 7: 49, 8: 64}"""

#-_--------------------------------------------------------------------------------------------------






"""#4.Write a program which accepts a sequence of comma-separated numbers from console and generate a list and a tuple which contains every number. 
Suppose the following input is supplied to the program: 
34,67,55,33,12,98 
Then, the output should be: 
['34', '67', '55', '33', '12', '98'] 
('34', '67', '55', '33', '12', '98') """

"""a=tuple(input().split())
print(a)
b=list(input().split())
print(b)"""


"""o/p:34 67 55 33 12 89
('34', '67', '55', '33', '12', '89')
34 67 55 33 12 89
['34', '67', '55', '33', '12', '89']"""

#--------------------------------------------------------------------------------------------


"""#5.Write a program that accepts a comma separated sequence of words as input
and prints the words in a comma-separated sequence after sorting them alphabetically. 
Suppose the following input is supplied to the program: 
without,hello,bag,world 
Then, the output should be: 
bag,hello,without,world """

a=input("enter words:").split(',')
a=list(a)
print(sorted(a))

"""o/p:enter words:without, hello, bag, world
[' bag', ' hello', ' world', 'without']"""

#------------------------------------------------------------------------------------------------------
#6Write a program that accepts sequence of lines as input and
#prints the lines after making all characters in the sentence capitalized. 
#Suppose the following input is supplied to the program: 
"""Hello world 
Practice makes perfect 
Then, the output should be: 
HELLO WORLD 
PRACTICE MAKES PERFECT"""
"""lines=int(input("Enter the number of line"))
ls=[]
for i in range(0,lines):
    line=input().upper()
    ls.append(line)
for i in ls:
    print(i)"""

#o/p:
"""Enter the number of line2
Hello world 
Practice makes perfect
HELLO WORLD 
PRACTICE MAKES PERFECT"""

#7.Write a program which accepts a sequence of comma separated 4 digit binary numbers as its input and then check whether they are divisible by 5 or not. The numbers that are divisible by 5 are to be printed in a comma separated sequence. 
#Example: 
#0100,0011,1010,1001 
#Then the output should be: 
#1010

"""ls=list(map(str,input("Enter the numbers").split(",")))
for i in ls:
    if int(i,2)%5==0:
        print(i)"""

"""Enter the numbers0100,0011,1010,1001
1010"""
#--------------------------------------------------------------------------------------------------

#8Write a program that accepts a sentence and calculate the number of
#upper case letters and lower case letters. 
#Suppose the following input is supplied to the program: 
#Hello world! 
#Then, the output should be: 
#UPPER CASE 1 
#LOWER CASE 9
"""a="Hello world"
uc=0
lc=0
for i in a:
    if (i.isupper()):
        uc+=1
    if(i.islower()):
        lc+=1
print("Upper Case", '=' ,uc)
print("lower Case", '=', lc)
output:Upper Case = 1
lower Case = 9"""

#9.Write a program to compute the frequency of the words from the input. The output should output after sorting the key alphanumerically.  
"""Suppose the following input is supplied to the program: 
New to Python or choosing between Python 2 and Python 3? Read Python 2 or Python 3. 
Then, the output should be: 
2:2 
3.:1 
3?:1 
New:1 
Python:5 
Read:1 
and:1 
between:1 
choosing:1 
or:2 
to:1"""

"""ls= list(map(str,input("Enter the string").split()))
for i in ls:
    print(i," : ",ls.count(i))"""

"""o\p:Enter the stringNew to Python or choosing between Python 2 and Python 3? Read Python 2 or Python 3
New  :  1
to  :  1
Python  :  5
or  :  2
choosing  :  1
between  :  1
Python  :  5
2  :  2
and  :  1
Python  :  5
3?  :  1
Read  :  1
Python  :  5
2  :  2
or  :  2
Python  :  5
3  :  1"""

#---------------------------------------------------------------------------------------------

#10.Convert 2nd Part of String into Upper Case
"""str1=input("Enter the string")
new_str=str1[:len(str1)//2]
for i in range(len(str1)//2,len(str1)):
    new_str+=str1[i].upper()
print(new_str)"""

"""o/p:Enter the string hello world
 hello WORLD"""

 
#11.With a given
#tuple (1,2,3,4,5,6,7,8,9,10), write a program to
#print the first half values in one line and the last half values in one line.\ 
"""tp=(1,2,3,4,5,6,7,8,9,10)
tp1=tp[:5]
tp2=tp[5:]
print(tp1)
print(tp2)

o/p(1, 2, 3, 4, 5)
(6, 7, 8, 9, 10)"""

