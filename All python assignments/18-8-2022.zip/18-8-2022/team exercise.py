"""1.Write a Python program find a list of integers with exactly two
occurrences of nineteen and at least three
occurrences of five. 
Input: 
[19, 19, 15, 5, 3, 5, 5, 2] 
Output: 
True """
"""a=input("enter values").split(',')
c1=0
c2=0
for i in a:
    if int(i)==19:
        c1+=1
    if int(i)==5:
        c2+=1
    if c1==2 and c2>=3:
        print("True")"""
        




#________________________________________________________________________________________________


#2.WAPP to check a given list of integers where the sum of the integers
#is equal to length of list.
"""l=[1,2,3,4]
s=0
for i in range(0,len(l)+1):
    s=s+i   
if s==len(l):
    print("sum of integers in a list is equal to length of a list", s)
else:
    print("Sum of integers is not equal to length of a list", s)"""


"""Sum of integers is not equal to length of a list 10"""

#____________________________________________________________________________________________

#3.WAPP to add two integers without using arithmetic operator
"""def add(a,b):
    for i in range(1,b+1):
        a=a+1
    return a
a=add(12,56)
print(a)"""

#68
