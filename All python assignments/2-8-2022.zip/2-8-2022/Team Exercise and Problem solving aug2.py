""""1.Calculate income tax for the given income by adhering to the below rules
Taxable Income    Rate (in %)
First $10,000    0
Next $10,000    10
The remaining    20
Expected Output:

For example, suppose the taxable income is 45000 the income tax payable is

10000*0% + 10000*10%  + 25000*20% = $6000."""

"""n=int(input("enter income:"))
if n<=10000:
    print("No Tax")
elif n>10000 and n<=20000:
    print("tax to be paid=", (n-10000)*10/100)
elif n>20000:
    print("tax to be paid=", 1000+(n-20000)*(20/100))"""
"""O\p: enter income:45000
6000.0"""
#--------------------------------------------------------------------------------------------------

"""2.Count the length of list with out using any inbuilt function"""

"""n=input("enter numbers in list").split(",")
j=0
for i in n:
    j+=1
print("length of list is :", j)"""
"""enter numbers in list4,8,9,0,7,6,1,2
length of list is : 8"""


"""3write a Python program to create a histogram from a given list of integers."""
'''a=[4,1,5,9]
for i in a:
    print('*'*i)'''
#output:
'''****
*
*****
*********'''
#------------------------------------------------------------------------------------------------
"""4. Take input from user and if input is string print String
if input is integer/float print integer
if input is mix of string and integer print Error
HINT Can be done using ASCII code"""

"""inpt=input("Enter the string ")
int_counter=0
str_counter=0
for i in inpt:
    if ord(i)>48 and ord(i)<57:
        int_counter+=1
    elif (ord(i)>97 and ord(i)<122) or (ord(i)>65 and ord(i)<90) :
        str_counter+=1

if int_counter >0 and str_counter ==0:
    print("Integer")
elif int_counter == 0 and str_counter >0:
    print("String")
else:
    print("Error")"""

"""o\p:
Enter the string welcome
String"""
#---------------------------------------------------------------------------------------------

#5.Python program to check if a string is palindrome or not
"""a=input("enter a string")
if a==a[::-1]:
    print("string is palindrome", a)
else:
    print("string is not palindrome", a)"""
"""o/p
  enter a stringmadam
string is palindrome madam  """

#--------------------------------------------------------------------------------------------------
#problem statement
"""krishna = [67,68,69]
Arjun = [70,98,63]
malika = [52,56,60]
krishna_sum = 67+68+69
krishna_avg = krishna_sum/3
print(round(krishna_avg))
Arjun_sum = 70+98+63
Arjun_avg = Arjun_sum/3
print(round(Arjun_avg/3))
malika_sum = 52+56+60
malika_avg = malika_sum/3
print(round(malika_avg))
if(krishna_avg<Arjun_avg)and(krishna_avg<malika_avg):
    print("the minimal avg of krisha: ",krishna_avg)
elif(Arjun_avg<krishna_avg)and(Arjun_avg<malika_avg):
    print("the minimal avg of Arjun: ",Arjun_avg)
else:
    print("the minimal avg of malika: ",malika_avg)"""
#o\p:68
"""26
56
the minimal avg of malika:  56.0"""
