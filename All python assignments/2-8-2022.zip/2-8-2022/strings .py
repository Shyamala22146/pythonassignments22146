
#1. How would you confirm that 2 strings have the same identity?

"""a=10
b=10
print(id(a),id(b))"""
#2. How would you check if each word in a string begins with a capital letter?
"""str1=input("enter a string")
for i in str1.split():
    if i[0].isupper():
        print(i)"""
"""o/penter a stringThis is a Beautiful Flower
This
Beautiful
Flower"""
#3. Check if a string contains a specific substring
"""str1="I love my Country"
if "my" in str1:
    print("my in main string")
else:
    print("my is not in main string")"""
    
"""o/p:my in main string"""
#4 Find the index of the first occurrence of a substring in a string
"""str1="I love my Country"
x=str1.find("my")
print(x)
o/p7"""
#5. Count the total number of characters in a string
"""str1="I love my Country"
print("length of str1 is :", len(str1))
length of str1 is : 17"""
#6.Count the number of a specific character in a string
"""str1="I love my Country"
for i in str1:
    count=0
while(str1[i]=="o"):
    count+=1
print(count)"""
#7Capitalize the first character of a string
"""str1="welcome"
print(str1.capitalize())
Welcome"""
#8What is an f-string and how do you use it?
#f-strings are string literals that have an f at the beginning
#and curly braces containing expressions that will be replaced with their values.

"""s="My name is {fname}, I'm {age}".format(fname = "John", age = 36)
print(s)"""
"""s="My name is {0}, I'm {1}".format("john",36)
print(s)"""
"""s="My name is {}, I'm {}".format("john",36)
print(s)"""
#9.Search a specific part of a string for a substring
"""str1="I love my Country"
if "love" in str1:
    print("love is in main string")
else:
    print("love is not in main string")
o/p:love is in main string"""
#10. Interpolate a variable into a string using format()
"""name="suhas"
age=34
purchased="apples"
print(f"my name {name} I'm {age} I purchased {purchased}")"""
#11Check if a string contains only numbers.
"""str1="abcdef123"
print(str1.isalnum())
True"""
#12 Split a string on a specific character
"""str1="abcdabdcd"
print(str1.split('a'))
['', 'bcd', 'bdcd']"""
# Check if a string is composed of all lower case characters
"""str1="abcASEDbdcd"
print(str1.islower())"""
#False
#Check if the first character in a string is lowercase
"""str1='Abcdefgh'
print(str1[0].islower())
False"""
#1515. Can an integer be added to a string in Python?
"""a="123"
b="xyz"
print(a+b)
123xyz"""
#16. Reverse the string “hello world”
"""a="hello world"
print(a[::-1])
dlrow olleh"""
#17.Join a list of strings into a single string, delimited by hyphens
"""a=['happy','morning']
print('-'.join(a))
happy-morning"""
#18. Check if all characters in a string conform to ASCI
#19. Uppercase or lowercase an entire string
"""a=input("enter a string")
a=a.isupper()
a=a.islower()
print(a)"""
#20. Uppercase first and last character of a string
#Check if a string is all uppercase
"""a="AbcDEF"
print(a.isupper())"""
False
#21. When would you use splitlines()?
"""The splitlines() method splits a string into a list.
The splitting is done at line breaks."""
#23Give an example of string slicing
"""a='welcome'
print(a[1])
print(a[2:5])
e
lco"""
#24Convert an integer to a string
"""a="123"

print(type(a))
<class 'str'>"""
#25Check if a string contains only characters of the alphabet
"""a="welcome"
print(a.isalpha())
True"""
#Replace all instances of a substring in a string
"""a='this is a book ,this is on table'
print(a.replace('this', 'that'))
that is a book ,that is on table"""
# Return the minimum character in a string
a='awelcomebbbeexc'
print(min(a))

#28. Check if all characters in a string are alphanumeric
"""a='welcom123'
print(a.isalnum())
True"""
#29. Remove whitespace from the left, right or both sides of a string
"""a='  welcome  '
print(a.strip())
welcome"""
#30. Check if a string begins with or ends with a specific character?
"""a='welcome'
print(a.startswith('w'))
print(a.endswith('e'))

True
True"""
