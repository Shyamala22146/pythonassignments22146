#1.WAP in python arrange string characters such that lowercase letters should come first
"""n =input("enter the string : ")
lower=""
upper=""
for i in n:
    if i.islower():
        lower+=i
    else:
        upper+=i
print(lower + upper,end = "")"""

"""enter the string : abcfGHIjkl
abcfjklGHI"""

#2.WAP to print sum of prime numbers in given list input :- 2 4 5 6 7 3 8 output :- 17
"""L=[2,4,5,6,7,3,8]
def add_prime(n):
    fact=1
    a=[]
    total=0
    for i in range(1,n+1):
        if n%i==0:
            a.append(i)
    if len(a)<=2:
        return n
    else:
        return 0
n=[2,4,5,6,7,3,8]
s=[]
for i in n:
    x=add_prime(i)
    s.append(x)
print(sum(s))"""
"""o/p
17"""


#3.e nested for loop.Write an example.
"""a loop inside a loop is known as a nested loop.
The inner or outer loop can be any type, such as a while loop or for loop"""
#4.WAP in python remove all characters from a string except integers
#(ex:- STR="H56U1E9JIG3l4w2" ,o/p:-5619342(only display integers) )

"""str1="H56U1E9JIG3l4w2"
num=filter(str.isdigit,str1)
nums="".join(num)
print(nums)"""
"""o\p
5619342"""

#5.WAP to take a list and find the possition of the item .(eg=  [45,12,66,2,33]
#if i take 66 then it shows the index 2)

"""L=[45,12,66,2,33]
for i in L:
    x=L.index(i)
    if i==66:
        print(i,"index", x)"""
#o\p:66 index 2
#__________________________________________
#problem solving
'''a=int(input("Enter first number:"))
b=int(input("Enter second number:"))
c=int(input("Enter third number:"))
d=[]
d.append(a)
d.append(b)
d.append(c)
for i in range(0,3):
    for j in range(0,3):
        for k in range(0,3):
            if(i!=j&j!=k&k!=i):
                print(d[i],d[j],d[k])



op/=Enter first number:4
Enter second number:5
Enter third number:6
4 5 6
4 6 5
5 4 6
5 6 4
6 4 5
6 5 4'''
