#1.write a python program to print the pattern
"""        * 
       * * 
      * * * 
     * * * * 
    * * * * * 
   * * * * * * 
    * * * * * 
     * * * * 
      * * * 
       * * 
        *"""
"""rows = int(input("Enter the number of rows: "))  
k = rows - 2  
# This is used to print the downward pyramid  
for i in range(rows, -1 , -1):  
    for j in range(k , 0 , -1):  
        print(end=" ")  
    k = k + 1  
    for j in range(0, i+1):  
        print("* " , end="")  
    print()"""  
  
#________________________________________________________________________________  
#2.How would you check if each word in a string begins with a capital letter?
"""s=input("enter a string:")
print(s.istitle())"""
"""o/p:
enter a string:Hyderabad
True"""
#_______________________________________________________________________________
#3.Write a Python program that prints all the numbers from 0 to 6 except 4 and 5.
"""for i in range(0,7):
    if i!=4 and i!=5:
        print(i)"""
"""0
1
2
3
6"""
#_____________________________________________________________________________________

#4.Print list of elements and store in a another list and print  reverse order of list
"""s=[]
a=input("enter elements in list ").split(',')
a.reverse()
print(a)"""
"""o/p:
enter elements in list 2,3,4
['4', '3', '2']"""
#5.write a python program to print the pattern
""" A  
           B C  
          D E F  
         G H I J  
        K L M N O  
       P Q R S T U"""
"""s = 6  
asciiValue = 65  
m = (2 * s) - 2  
for i in range(0, s):  
    for j in range(0, m):  
        print(end=" ")  
    # Decreased the value of after each iteration  
    m = m - 1  
    for j in range(0, i + 1):  
        alphabate = chr(asciiValue)  
        print(alphabate, end=' ')  
        # Increase the ASCII number after each iteration  
        asciiValue += 1  
    print()""" 
"""A 
         B C 
        D E F 
       G H I J 
      K L M N O 
     P Q R S T U """

"""d=['cat', 'dog', 'shatter', 'donut', 'at', 'todo', 'car']
prefix=('ca','do')
x=[]
for i in d:
    if i.startswith(prefix):
        x.append(i)
print(x)"""
#output:['cat', 'dog', 'donut', 'car']
