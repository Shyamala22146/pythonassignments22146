#1WAP for eligibility of a canditate voter_id,
  #suppose age between (18 to 80 years old) using flow control conditions?

"""age=int(input("enter age of candidate:"))
if age>=18 and age<=80:
    print("eligible for voting:", age)
else:
    print("Not eligible for Voting:", age)"""
#2.WAP for calculating student marks in 5-subjects,and
#find  grades,(suppose grade A,B,C and Fail)?
"""n1=int(input("enter marks in subject1:"))
n2=int(input("enter marks in subject2:"))
n3=int(input("enter marks in subject3:"))
n4=int(input("enter marks in subject4:"))
n5=int(input("enter marks in subject5:"))
sum=n1+n2+n3+n4+n5
avg=sum/5
print(avg)
if avg>85 and avg<85:
    print('grade A')
elif avg<85 and avg>75:
    print('grade B')
elif avg<75 and avg>60:
    print('grade C')
else:
    print('Fail')"""
"""o\p:
    enter marks in subject1:56
enter marks in subject2:85
enter marks in subject3:99
enter marks in subject4:75
enter marks in subject5:88
80.6"""

#3.WAP for finding  even or odd number using (if .. else ... condition)?


"""a=int(input("enter a number:"))
if a%2==0:
    print("given number is even number:", a)
else:
        print("given number is odd:", a)"""


"""o/p:
    enter a number:25
given number is odd: 25"""
#4.WAP calculating area of a circle, result in positive integers only not in float values
#(hint: pi=3.14,using int() function)?
"""R= int(input("Enter a Radius:"))
pi=3.14

A= pi*R**2

print("Area of a circle is:", int(A))"""

"""o/pEnter a Radius:4
Area of a circle is: 50"""
#5.WAP for finding  variables A and B are having the same memory location?
"""a=int(input("enter a number1:" ))
b=int(input("enter a number2:"))
if id(a)==id(b):
    print("having same memory location")
else:
    print("not having same memory location")"""

"""o\p:enter a number1:25
enter a number2:26
not having same memory location""


#problem statement
"""Num=int(input("Enter the value of Num:"))
if(Num<20):
    for i in range(0,Num):
        i=i**2
        print(i)
'''OUTPUT:
          Enter the value of Num:5
          0
          1
          4
          9
          16"""


