#1.WAP to find the target value of 5 in the given list of 1,5,7,8,90,6,and 23
#elements?
"""t=5
list_1=[1,5,7,8,90,6,23]
for i in range (len(list_1)):
    if list_1[i]==t:
        print("target value:", t)"""
 
"""O\p:target value: 5"""
#2. WAP to sort the given list of elements 1,5,7,8,90,6,and 23,
#without using sort() function?
"""list_1=[1,5,7,8,90,6,23]
for i in range (len(list_1)):
    for j in range(i+1, len(list_1)):
        if list_1[i]>list_1[j]:
            list_1[i],list_1[j]=list_1[j],list_1[i]
print(list_1)
#o/p:[1, 5, 6, 7, 8, 23, 90]"""    
#3. WAP to calcalte the compound interest of 3 years with the principle amount of RS:10000 
#  and rate of return is 5 percentage for annum.and display the total amount to pay on  the end of the year.?
"""p=int(input("enter principal amount:"))
t=int(input("enter number of years:"))
r=int(input("enter rate:"))
a=p*(1+(r/100))**t  
ci=a-p  
print(ci)"""
"""enter principal amount:10000
enter number of years:3
enter rate:5
1576.2500000000018"""

#5. WAP pattern program

""""n = 4
for i in range(n-1):
    for j in range(i):
        print(' ', end='')
    for k in range(2*(n-i)-1):
        print('*', end='')
    print()

for i in range(n):
    for j in range(n-i-1):
        print(' ', end='')
    for k in range(2*i+1):
        print('*', end='')
    print()"""

"""o/p
*******
 *****
  ***
   *
  ***
 *****
*******"""
    


