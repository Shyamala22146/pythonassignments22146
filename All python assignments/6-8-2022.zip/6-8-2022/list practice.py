#copy
## Shallow Copy
"""lst1=[1,2,3,4]
lst2=lst1.copy()
print(lst2)
lst2[1]=1000
print(lst2)
print(lst1)
[1, 2, 3, 4]
[1, 1000, 3, 4]
[1, 2, 3, 4]
print(lst2)
lst1[3]=34
print(lst1)
print(lst2)"""
lst1=[[1,2,3,4],[5,6,7,8]]
lst2=lst1.copy()
"""lst1[1][3]=100
print(lst1)
print(lst2)
lst1.append([2,3,4,5,6])
print(lst1)
print(lst2)"""
"""lst2.append([7,8,9,0])
print(lst1)
print(lst2)"""

