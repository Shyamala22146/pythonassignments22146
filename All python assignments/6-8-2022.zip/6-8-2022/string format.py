# Integer

"""print("******** Integer *********")

print("{}".format(10))

print("{} {}".format(10, 20))

print("{0}".format(10))

print("{0} {1}".format(10, 20))

print("{1} {0}".format(10, 20))

print("{num1}".format(num1=10))

print("{num1} {num2}".format(num1=10, num2=20))

print("{num2} {num1}".format(num1=10, num2=20))
******** Integer *********
10
10 20
10
10 20
20 10
10
10 20
20 10"""
#----------------------------------------------------------------------------------------------


"""print("******** Float *********")

print("{}".format(10.56))

print("{} {}".format(10.56, 20.42))

print("{0}".format(10.56))

print("{0} {1}".format(10.56, 20.42))

print("{1} {0}".format(10.56, 20.42))

print("{num1}".format(num1=10.56))

print("{num1} {num2}".format(num1=10.56, num2=20.42))

print("{num2} {num1}".format(num1=10.56, num2=20.42))
10.56
10.56 20.42
10.56
10.56 20.42
20.42 10.56
10.56
10.56 20.42
20.42 10.56"""
#_____________________________________________________________________________________________
"""print("{0}".format("apple"))

print("{0} {1}".format("apple", "banana"))

print("{1} {0}".format("apple", "banana"))

print("{str1}".format(str1="apple"))

print("{str1} {str2}".format(str1="apple", str2="banana"))

print("{str2} {str1}".format(str1="apple", str2="banana"))
apple
apple banana
banana apple
apple
apple banana
banana apple"""
#-----------------------------------------------------------------------------------------------
# Integer and String

"""print("Hello My Name is {}".format("alex"))

print("{} {}".format(10, "banana"))

print("{0} {1}".format(10, "banana"))

print("{1} {0}".format(10, "banana"))

print("{num1} {str1}".format(num1=10, str1="banana"))

print("{str1} {num1}".format(num1=10, str1="banana"))
Hello My Name is alex
10 banana
10 banana
banana 10
10 banana
banana 10"""
#______________________________________________________________________________________________
#Comma as thousand Separator

"""print("{:,}".format(1234567890123456789))
1,234,567,890,123,456,789"""
#______________________________________________________________________________________________
#variable

"""name = "Rahul"

age= 62

print("My name is {} and age {}".format(name, age))
My name is Rahul and age 62"""
#______________________________________________________________________________________________
# Expressing a Percentage

"""a = 50

b = 3

print("{:.2%}".format(a/b))
1666.67%"""
#_______________________________________________________________________________________________
"""value = (10, 20)

print("{0[0]} {0[1]}".format(value))"""

#-----------------------------------------------------------------------------------------------
# Format with Dict

"""data1 = {'rahul': 2000, 'sonam': 3000}

print("{0[rahul]:d} {0[sonam]:d}".format(data1))

2000 3000"""
#----------------------------------------------------------------------------------------------
# Format with Dict

"""data2 = {'rahul': 2000, 'sonam': 3000}

print("{d[rahul]:d} {d[sonam]:d}".format(d=data2))

# Accessing arguments by name:

data3 = {'rahul': 2000, 'sonam': 3000,'ajay':4000}

print("{rahul} {sonam} {ajay}".format(**data3))

# ** is a format parameter (minimum field width)
2000 3000
2000 3000 4000"""
#______________________________________________________________________________________________
# Integer

"""print("******** Integer ********")

print("{}".format(15)) # Printing as string 15

print("{:d}".format(15))

print("{0:d}".format(15))

print("{num:d}".format(num=15))

print("{num:5d}".format(num=15))

print("{num:05d}".format(num=15))

print("{num:+5d}".format(num=15))

print("{num:<5d}".format(num=15)) # Left align

print("{num:*<5d}".format(num=15)) # Left align with fill

print("{num:*>5d}".format(num=15)) # Right align with fill

print("{num:^5d}".format(num=15)) # Center align

print("{num:*^5d}".format(num=15)) # Center align with fill
******** Integer ********
15
15
15
15
   15
00015
  +15
15   
15***
***15
 15  
*15**"""
"""print("******** Float ********")

print("{}".format(15.65)) # Printing as string 15.65

print("{:f}".format(15.65))

print("{0:f}".format(15.65))

print("{num:f}".format(num=15.65))

print("{num:8f}".format(num=15.65)) # 15.650000

print("{num:8.3f}".format(num=15.65))

print("{num:+8.2f}".format(num=15.65))

print("{num:<8.2f}".format(num=15.65)) # Left align

print("{num:*<8.2f}".format(num=15.65)) # Left align with fill

print("{num:*>8.2f}".format(num=15.65)) # Right align with fill

print("{num:^8.2f}".format(num=15.65)) # Center align

print("{num:*^8.4f}".format(num=15.65))""" # Center align with fill
"""******** Float ********
15.65
15.650000
15.650000
15.650000
15.650000
  15.650
  +15.65
15.65   
15.65***
***15.65
 15.65  
15.6500*"""
'''String'''

"""print("******** String ********")

print("{:8s}".format("apple"))

print("{:<8}".format("apple"))

print("{:*<8}".format("apple"))

print("{:>8}".format("apple"))

print("{:*>7s}".format("apple"))

print("{:^9s}".format("apple"))

print("{:*^7s}".format("apple"))"""
"""******** String ********
apple   
apple   
apple***
   apple
**apple
  apple  
*apple*"""

print("******** Truncating String ********")

print("{:.3s}".format("ojas"))

print("{:8.3s}".format("ojas"))

print("{:*<8.3s}".format("ojas"))

print("{:>8.3s}".format("ojas"))

print("{:*>8.3s}".format("ojas"))

print("{:^8.3s}".format("ojas"))

print("{:*^8.3s}".format("ojas"))
"""******** Truncating String ********
oja
oja     
oja*****
     oja
*****oja
  oja   
**oja***
>>> """
# Integer

"""print("******** Integer *********")

a = 10

b = 20

print(f"{a}") # empty expression not allowed

print(f"{a} {b}")

print(f"{b} {a}")
******** Integer *********
10
10 20
20 10"""
# Integer and String

"""name = "alex albert"

age = 10

print(f"Hello My Name is {name}")

print(f"{name} {age}")

print(f"{age} {name}")"""
"""Hello My Name is alex albert
alex albert 10
10 alex albert"""



print("******** Integer ********")

"""num = 15

print(f"{num}") # Treated as String becoz no type mention

print(f"{num:d}")

print(f"{num:5d}")

print(f"{num:05d}")

print(f"{num:+5d}")

print(f"{num:<5d}") # Left align

print(f"{num:*<5d}") # Left align with fill

print(f"{num:*>5d}") # Right align with fill

print(f"{num:^5d}") # Center align
print(f"{num:*^5d}") # Center align with fill
******** Integer ********
15
15
   15
00015
  +15
15   
15***
***15
 15  
*15**"""
#Calling Function

"""name= "alexalbert"

print(f"{name}")

print(f"{name.upper()}")
alexalbert
ALEXALBERT"""
# Curly Braces

print(f"{10}")

print(f"{{10}}")

# Date and Time

from datetime import datetime

"""today = datetime(2022, 8, 7)

print(f"{today}")

print(f"{today:%d-%b-%Y}")

print(f"{today:%d/%b/%Y}")

print(f"{today:%b/%d/%Y}")"""

"""10
{10}
2022-08-07 00:00:00
07-Aug-2022
07/Aug/2022
Aug/07/2022"""

"""print("%d" % 432)

print("%d %d" % (432, 345))

print("%f" %432.123)

print("%f %f" %(432.123, 10.3))

print("%f" %432.123456)

print("%f" %432.12345651)

print("%s" % "alexalbert")

print("%s %s" % ("Hello", "alexalbert"))

print("%d %s" % (432, "alexalbert"))

#print("%s %d" % (432, "alexalbert")) TypeError

print("%(nm)s %(ag)d" % {'ag':432, 'nm':"alexalbert"})

print("% d" % 432)

print("% d" % 432)

print("%+d" % 432)

print("%8d" % 432)

print("%08d" % 432)

print("%.3f" %432.123)

print("%.2f" %432.123)

print("%.2f" %432.128)

print("%9.2f" %432.128)

print("%09.2f" %432.123)

print("%9.2f" %4388453232.124)
432
432 345
432.123000
432.123000 10.300000
432.123456
432.123457
alexalbert
Hello alexalbert
432 alexalbert
alexalbert 432
 432
 432
+432
     432
00000432
432.123
432.12
432.13
   432.13
000432.12
4388453232.12"""
>>> 
