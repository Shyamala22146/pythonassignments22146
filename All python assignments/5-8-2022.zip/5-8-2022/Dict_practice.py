#dict={'fruit':'apple', 'colour':'red','price':100}
"""print(dict)
{'fruit': 'apple', 'colour': 'red', 'price': 100}"""
# to print with key
"""print(dict['colour'])"""


"""dict={'fruit':'apple', 'colour':'red','price':100,'price':200}
print(dict)"""
#{'fruit': 'apple', 'colour': 'red', 'price': 200}
#it overwrites the previou values.no duplicates are allowed.

"""dict={'fruit':'apple', 'colour':'red','price':100,'price':200}
print(len(dict))"""
#O\p:
#len=3: it will not consider repeated values:

'''dict={'fruit':'apple', 'colour':['red','white','blue'],'price':200}
print(dict)
print(type(dict))
{'fruit': 'apple', 'colour': ['red', 'white', 'blue'], 'price': 200}
<class 'dict'>'''

"""dict={'fruit':'apple', 'colour':['red','white','blue'],'price':200}
print(dict['colour'])
['red', 'white', 'blue']"""


#dict={'fruit':'apple', 'colour':['red','white','blue'],'price':200}
#print(dict.get('fruit'))
#get method is used to get values with keys.
#print(dict.keys())
#dict_keys(['fruit', 'colour', 'price'])
#to get all keys in dict.
"""dict['place']='shimla'
print(dict)"""
"""dict.update({'Available':'yes', 'Market':'yes'})
print(dict)
{'fruit': 'apple', 'colour': ['red', 'white', 'blue'], 'price': 200, 'Available': 'yes', 'Market': 'yes'}

print(dict.clear())"""
"""print(dict)
dict.clear()
print(dict)"""
dict={'fruit':'apple', 'colour':'red','price':100}
"""for i in dict:
    print(i)"""
for i in dict.values():
    print(i)

